import React from 'react';
import { motion } from 'framer-motion';

const TokenomicsCard = ({ title, percentage, description }) => {
  return (
    <motion.div 
      className="card text-center"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.05 }}
    >
      <div className="relative mb-4 mx-auto w-24 h-24 flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <circle 
            cx="50" 
            cy="50" 
            r="45" 
            fill="none" 
            stroke="#2a2a4e" 
            strokeWidth="10" 
          />
          <circle 
            cx="50" 
            cy="50" 
            r="45" 
            fill="none" 
            stroke="#ff6b6b" 
            strokeWidth="10" 
            strokeDasharray="283" 
            strokeDashoffset={283 - (parseInt(percentage) / 100 * 283)} 
            transform="rotate(-90 50 50)" 
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-2xl font-bold text-accent">
          {percentage}
        </div>
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-400 text-sm">{description}</p>
    </motion.div>
  );
};

export default TokenomicsCard;