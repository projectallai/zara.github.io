import React from 'react';
import { motion } from 'framer-motion';

const RoadmapItem = ({ phase, title, items, isLeft }) => {
  return (
    <div className={`flex items-center ${isLeft ? 'flex-row' : 'flex-row-reverse'}`}>
      <motion.div 
        className={`w-full md:w-5/12 ${isLeft ? 'text-right pr-8' : 'text-left pl-8'}`}
        initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <div className={`card ${isLeft ? 'ml-auto' : 'mr-auto'}`}>
          <h3 className="text-accent font-bold mb-1">{phase}</h3>
          <h4 className="text-xl font-bold mb-4">{title}</h4>
          <ul className={`space-y-2 text-gray-300 ${isLeft ? 'text-right' : 'text-left'}`}>
            {items.map((item, index) => (
              <li key={index} className="flex items-center gap-2">
                {!isLeft && <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0"></div>}
                <span>{item}</span>
                {isLeft && <div className="w-2 h-2 rounded-full bg-accent ml-auto flex-shrink-0"></div>}
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
      
      <motion.div 
        className="relative z-10"
        initial={{ scale: 0 }}
        whileInView={{ scale: 1 }}
        transition={{ duration: 0.4 }}
        viewport={{ once: true }}
      >
        <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
          <div className="w-4 h-4 bg-primary rounded-full"></div>
        </div>
      </motion.div>
      
      <div className="w-full md:w-5/12"></div>
    </div>
  );
};

export default RoadmapItem;