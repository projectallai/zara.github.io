import React from 'react';
import { motion } from 'framer-motion';

const CatImage = () => {
  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80">
      <div className="absolute inset-0 bg-accent/20 rounded-full blur-3xl"></div>
      
      <motion.div 
        className="relative z-10 w-full h-full flex items-center justify-center"
        initial={{ rotate: 0 }}
        animate={{ rotate: [0, 5, 0, -5, 0] }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
      >
        <svg 
          viewBox="0 0 200 200" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-lg"
        >
          {/* Cat body */}
          <circle cx="100" cy="100" r="70" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="3" />
          
          {/* Cat ears */}
          <path d="M60,60 Q50,30 70,50" fill="#ff6b6b" />
          <path d="M140,60 Q150,30 130,50" fill="#ff6b6b" />
          
          {/* Cat eyes */}
          <g className="cat-eyes">
            <circle cx="75" cy="85" r="10" fill="white" />
            <circle cx="125" cy="85" r="10" fill="white" />
            <circle cx="75" cy="85" r="5" fill="#1a1a2e">
              <animate 
                attributeName="cx" 
                values="73;77;73" 
                dur="3s" 
                repeatCount="indefinite" 
              />
            </circle>
            <circle cx="125" cy="85" r="5" fill="#1a1a2e">
              <animate 
                attributeName="cx" 
                values="123;127;123" 
                dur="3s" 
                repeatCount="indefinite" 
              />
            </circle>
          </g>
          
          {/* Cat nose */}
          <path d="M95,105 L100,110 L105,105 Z" fill="#ff6b6b" />
          
          {/* Cat mouth */}
          <path d="M90,115 Q100,125 110,115" stroke="#ff6b6b" strokeWidth="2" fill="none" />
          
          {/* Cat whiskers */}
          <line x1="50" y1="105" x2="80" y2="110" stroke="#ff6b6b" strokeWidth="1" />
          <line x1="50" y1="115" x2="80" y2="115" stroke="#ff6b6b" strokeWidth="1" />
          <line x1="50" y1="125" x2="80" y2="120" stroke="#ff6b6b" strokeWidth="1" />
          
          <line x1="150" y1="105" x2="120" y2="110" stroke="#ff6b6b" strokeWidth="1" />
          <line x1="150" y1="115" x2="120" y2="115" stroke="#ff6b6b" strokeWidth="1" />
          <line x1="150" y1="125" x2="120" y2="120" stroke="#ff6b6b" strokeWidth="1" />
          
          {/* Coin effect */}
          <circle cx="100" cy="100" r="85" fill="none" stroke="#ff6b6b" strokeWidth="2" strokeDasharray="5,5" />
          <text x="100" y="40" textAnchor="middle" fill="#ff6b6b" fontSize="16" fontWeight="bold">ZARA</text>
        </svg>
      </motion.div>
      
      {/* Floating coins */}
      <motion.div 
        className="absolute -top-10 -left-10 w-12 h-12"
        animate={{ y: [0, -20, 0], rotate: 360 }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
      >
        <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
          <circle cx="25" cy="25" r="23" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="2" />
          <text x="25" y="30" textAnchor="middle" fill="#ff6b6b" fontSize="10">Z</text>
        </svg>
      </motion.div>
      
      <motion.div 
        className="absolute -bottom-5 -right-5 w-10 h-10"
        animate={{ y: [0, 15, 0], rotate: -360 }}
        transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
      >
        <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
          <circle cx="25" cy="25" r="23" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="2" />
          <text x="25" y="30" textAnchor="middle" fill="#ff6b6b" fontSize="10">Z</text>
        </svg>
      </motion.div>
    </div>
  );
};

export default CatImage;