import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaTwitter, FaTelegram, FaChartLine, FaExchangeAlt, FaShieldAlt, FaRobot, FaBrain, FaCode } from 'react-icons/fa';
import CatImage from './components/CatImage';
import Navbar from './components/Navbar';
import TokenomicsCard from './components/TokenomicsCard';
import RoadmapItem from './components/RoadmapItem';

function App() {
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const parallaxElements = document.querySelectorAll('.parallax');
      
      parallaxElements.forEach(element => {
        const speed = element.getAttribute('data-speed');
        element.style.transform = `translateY(${scrollPosition * speed}px)`;
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-primary text-white overflow-hidden">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 left-10 w-32 h-32 bg-accent/10 rounded-full blur-3xl parallax" data-speed="0.3"></div>
          <div className="absolute bottom-20 right-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl parallax" data-speed="0.2"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto max-w-6xl z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <motion.div 
              className="md:w-1/2 text-center md:text-left"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4">
                <span className="gradient-text">ZARA</span> AI
              </h1>
              <p className="text-xl md:text-2xl mb-6 text-gray-300">The smartest AI agent meme coin in crypto! 🤖</p>
              <p className="mb-8 text-gray-400">Join our community and be part of the AI-powered crypto revolution!</p>
              
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <a href="#" className="btn btn-primary flex items-center gap-2">
                  <FaExchangeAlt /> Buy Now
                </a>
                <a href="#tokenomics" className="btn btn-outline flex items-center gap-2">
                  <FaChartLine /> Tokenomics
                </a>
              </div>
              
              <div className="mt-8 flex gap-6 justify-center md:justify-start">
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <FaTwitter />
                </a>
              </div>
            </motion.div>
            
            <motion.div 
              className="md:w-1/2 flex justify-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="relative">
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                >
                  <AIAgentImage />
                </motion.div>
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-40 h-10 bg-accent/30 rounded-full blur-xl"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section className="py-20 bg-secondary relative">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About <span className="gradient-text">ZARA AI</span></h2>
            <div className="w-20 h-1 bg-accent mx-auto mb-8"></div>
            <p className="max-w-2xl mx-auto text-gray-300">
              Zara AI is not just another meme coin. It's a community-driven project inspired by the rapid advancement of AI technology.
              With our intelligent AI agent mascot leading the way, we're creating a fun and engaging ecosystem for crypto enthusiasts.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              viewport={{ once: true }}
              className="card"
            >
              <div className="text-accent text-4xl mb-4">
                <FaRobot />
              </div>
              <h3 className="text-xl font-bold mb-2">AI-Powered</h3>
              <p className="text-gray-400">Leveraging artificial intelligence for community insights and market analysis.</p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="card"
            >
              <div className="text-accent text-4xl mb-4">
                <FaBrain />
              </div>
              <h3 className="text-xl font-bold mb-2">Community Driven</h3>
              <p className="text-gray-400">Decisions made by the community for the community with AI assistance.</p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
              className="card"
            >
              <div className="text-accent text-4xl mb-4">
                <FaCode />
              </div>
              <h3 className="text-xl font-bold mb-2">Smart Contract</h3>
              <p className="text-gray-400">Advanced smart contract with built-in AI-inspired tokenomics.</p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Tokenomics Section */}
      <section id="tokenomics" className="py-20 bg-primary relative">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 right-20 w-32 h-32 bg-accent/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-20 w-40 h-40 bg-accent/10 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto max-w-6xl px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Tokenomics</h2>
            <div className="w-20 h-1 bg-accent mx-auto mb-8"></div>
            <p className="max-w-2xl mx-auto text-gray-300">
              ZARA AI has a total supply of 1,000,000,000,000 tokens with an AI-optimized distribution model.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <TokenomicsCard title="Liquidity Pool" percentage="40%" description="Locked for 2 years to ensure long-term stability" />
            <TokenomicsCard title="Community" percentage="30%" description="Reserved for community rewards and AI development" />
            <TokenomicsCard title="Development" percentage="20%" description="For ongoing AI integration and marketing" />
            <TokenomicsCard title="Team" percentage="10%" description="Vested over 24 months for long-term alignment" />
          </div>
          
          <div className="mt-16 card">
            <h3 className="text-xl font-bold mb-4 text-center">Tax Structure</h3>
            <div className="p-4 bg-primary/50 rounded-lg">
              <h4 className="font-bold text-accent mb-2">Buy Tax: 5%</h4>
              <ul className="list-disc list-inside text-gray-300">
                <li>3% Marketing</li>
                <li>2% Liquidity</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Roadmap Section */}
      <section className="py-20 bg-secondary relative">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Roadmap</h2>
            <div className="w-20 h-1 bg-accent mx-auto mb-8"></div>
            <p className="max-w-2xl mx-auto text-gray-300">
              Our journey to make ZARA AI the smartest and most successful AI-themed meme coin.
            </p>
          </motion.div>
          
          <div className="relative">
            <div className="absolute left-1/2 -translate-x-1/2 w-1 h-full bg-accent/30"></div>
            
            <div className="space-y-12">
              <RoadmapItem 
                phase="Phase 1" 
                title="Launch & Community Building" 
                items={[
                  "Website and social media launch",
                  "Community building on Twitter",
                  "Initial marketing campaign",
                  "Token launch on DEX"
                ]}
                isLeft={true}
              />
              
              <RoadmapItem 
                phase="Phase 2" 
                title="AI Integration & Growth" 
                items={[
                  "CoinGecko and CoinMarketCap listings",
                  "AI-powered community analytics dashboard",
                  "Partnerships with AI projects",
                  "Enhanced marketing campaigns"
                ]}
                isLeft={false}
              />
              
              <RoadmapItem 
                phase="Phase 3" 
                title="Utility Development" 
                items={[
                  "AI-generated NFT collection launch",
                  "AI-powered staking platform",
                  "AI trading bot for community members",
                  "AI research funding initiatives"
                ]}
                isLeft={true}
              />
              
              <RoadmapItem 
                phase="Phase 4" 
                title="Ecosystem Expansion" 
                items={[
                  "CEX listings",
                  "AI-powered mobile app development",
                  "Cross-chain integration",
                  "AI-enhanced DAO governance implementation"
                ]}
                isLeft={false}
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Community Section */}
      <section className="py-20 bg-primary relative">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Community</h2>
            <div className="w-20 h-1 bg-accent mx-auto mb-8"></div>
            <p className="max-w-2xl mx-auto text-gray-300">
              Be part of the ZARA AI community and stay updated on the latest AI advancements and token developments.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-1 gap-8">
            <motion.a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="card flex items-center p-8 hover:border-accent transition-all duration-300"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.03 }}
            >
              <FaTwitter className="text-5xl text-accent mr-6" />
              <div>
                <h3 className="text-xl font-bold mb-1">Twitter</h3>
                <p className="text-gray-400">Follow us for the latest updates and AI-powered insights</p>
              </div>
            </motion.a>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-10 bg-dark">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">
                <span className="gradient-text">ZARA</span> AI
              </h2>
              <p className="text-gray-400 mt-2">The smartest meme coin in crypto</p>
            </div>
            
            <div className="flex gap-6">
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon">
                <FaTwitter />
              </a>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-500">
            <p>© 2025 ZARA AI. All rights reserved.</p>
            <p className="mt-2 text-sm">
              ZARA AI is a meme coin with no intrinsic value or financial return. This website does not constitute financial advice.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

const AIAgentImage = () => {
  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80">
      <div className="absolute inset-0 bg-accent/20 rounded-full blur-3xl"></div>
      
      <motion.div 
        className="relative z-10 w-full h-full flex items-center justify-center"
        initial={{ rotate: 0 }}
        animate={{ rotate: [0, 5, 0, -5, 0] }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
      >
        <svg 
          viewBox="0 0 200 200" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-lg"
        >
          {/* Robot head */}
          <rect x="50" y="40" width="100" height="120" rx="10" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="3" />
          
          {/* Robot antenna */}
          <line x1="100" y1="40" x2="100" y2="20" stroke="#ff6b6b" strokeWidth="3" />
          <circle cx="100" cy="15" r="5" fill="#ff6b6b" />
          
          {/* Robot eyes */}
          <g className="robot-eyes">
            <rect x="65" y="70" width="25" height="15" rx="3" fill="#ff6b6b" />
            <rect x="110" y="70" width="25" height="15" rx="3" fill="#ff6b6b" />
            
            <rect x="70" y="75" width="15" height="5" fill="#1a1a2e">
              <animate 
                attributeName="x" 
                values="70;75;70" 
                dur="3s" 
                repeatCount="indefinite" 
              />
            </rect>
            <rect x="115" y="75" width="15" height="5" fill="#1a1a2e">
              <animate 
                attributeName="x" 
                values="115;120;115" 
                dur="3s" 
                repeatCount="indefinite" 
              />
            </rect>
          </g>
          
          {/* Robot mouth */}
          <rect x="70" y="100" width="60" height="10" rx="5" fill="#ff6b6b" />
          <line x1="75" y1="105" x2="125" y2="105" stroke="#1a1a2e" strokeWidth="2" strokeDasharray="5,3" />
          
          {/* Robot ears */}
          <rect x="40" y="70" width="10" height="30" rx="2" fill="#ff6b6b" />
          <rect x="150" y="70" width="10" height="30" rx="2" fill="#ff6b6b" />
          
          {/* Robot neck */}
          <rect x="85" y="160" width="30" height="10" fill="#ff6b6b" />
          
          {/* Digital circuit patterns */}
          <path d="M60,130 H80 V140 H100 V130 H120" fill="none" stroke="#ff6b6b" strokeWidth="1" />
          <circle cx="60" cy="130" r="2" fill="#ff6b6b" />
          <circle cx="80" cy="130" r="2" fill="#ff6b6b" />
          <circle cx="80" cy="140" r="2" fill="#ff6b6b" />
          <circle cx="100" cy="140" r="2" fill="#ff6b6b" />
          <circle cx="100" cy="130" r="2" fill="#ff6b6b" />
          <circle cx="120" cy="130" r="2" fill="#ff6b6b" />
          
          {/* Coin effect */}
          <circle cx="100" cy="100" r="85" fill="none" stroke="#ff6b6b" strokeWidth="2" strokeDasharray="5,5" />
          <text x="100" y="40" textAnchor="middle" fill="#ff6b6b" fontSize="16" fontWeight="bold">ZARA AI</text>
        </svg>
      </motion.div>
      
      {/* Floating binary */}
      <motion.div 
        className="absolute -top-10 -left-10 w-12 h-12"
        animate={{ y: [0, -20, 0], rotate: 360 }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
      >
        <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
          <circle cx="25" cy="25" r="23" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="2" />
          <text x="25" y="30" textAnchor="middle" fill="#ff6b6b" fontSize="10">01</text>
        </svg>
      </motion.div>
      
      <motion.div 
        className="absolute -bottom-5 -right-5 w-10 h-10"
        animate={{ y: [0, 15, 0], rotate: -360 }}
        transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
      >
        <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
          <circle cx="25" cy="25" r="23" fill="#1a1a2e" stroke="#ff6b6b" strokeWidth="2" />
          <text x="25" y="30" textAnchor="middle" fill="#ff6b6b" fontSize="10">10</text>
        </svg>
      </motion.div>
    </div>
  );
};

export default App;